package dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import model.ModelProduct;

public class DaoProduct implements IDaoProduct {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Override
    public ModelProduct getProduct(String name) {
        ModelProduct product = new Model
        return null;
    }
    
    @Override
    public ModelProduct getException(String name) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }
}
