package aop;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestFirstAspect {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }
    
    @Test
    public void test() {
        fail("Not yet implemented");
    }
}
